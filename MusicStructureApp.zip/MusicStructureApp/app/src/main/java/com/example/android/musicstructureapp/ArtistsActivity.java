package com.example.android.musicstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ArtistsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Artists");
        setContentView(R.layout.activity_artists);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        TextView artist0 = (TextView) findViewById(R.id.artists0);
        TextView artist1 = (TextView) findViewById(R.id.artists1);
        TextView artist2 = (TextView) findViewById(R.id.artists2);


        artist0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artistIntent = new Intent(ArtistsActivity.this, ArtistDetailActivity.class);
                startActivity(artistIntent);
            }
        });

        artist1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artist1Intent = new Intent(ArtistsActivity.this, ArtistDetailActivity.class);
                startActivity(artist1Intent);
            }
        });

        artist2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artist2Intent = new Intent(ArtistsActivity.this, ArtistDetailActivity.class);
                startActivity(artist2Intent);
            }
        });

    }
}
