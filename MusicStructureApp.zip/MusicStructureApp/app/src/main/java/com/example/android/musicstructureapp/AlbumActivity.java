package com.example.android.musicstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AlbumActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Albums");
        setContentView(R.layout.activity_album);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        TextView albums0 = (TextView) findViewById(R.id.albums0);
        TextView albums1 = (TextView) findViewById(R.id.albums1);
        TextView albums2 = (TextView) findViewById(R.id.albums2);


        albums0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent album0Intent = new Intent(AlbumActivity.this, AlbumsDetailActivity.class);
                startActivity(album0Intent);
            }
        });


        albums1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent albums1Intent = new Intent(AlbumActivity.this, AlbumsDetailActivity.class);
                startActivity(albums1Intent);
            }
        });

        albums2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent albums2Intent = new Intent(AlbumActivity.this, AlbumsDetailActivity.class);
                startActivity(albums2Intent);
            }
        });
    }
}
