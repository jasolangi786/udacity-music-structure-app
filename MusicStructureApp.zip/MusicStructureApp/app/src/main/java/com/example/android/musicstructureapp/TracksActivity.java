package com.example.android.musicstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class TracksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Tracks");
        setContentView(R.layout.activity_tracks);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        TextView track0 = (TextView) findViewById(R.id.track0);
        TextView track1 = (TextView) findViewById(R.id.track1);
        TextView track2 = (TextView) findViewById(R.id.track2);


        track0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent track0Intent = new Intent (TracksActivity.this, TracksDetailActivity.class);
                startActivity(track0Intent);
            }
        });

    track1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent track1Intent = new Intent(TracksActivity.this, TracksDetailActivity.class);
            startActivity(track1Intent);
        }
    });

        track2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent track2Intent = new Intent(TracksActivity.this, TracksDetailActivity.class);
                startActivity(track2Intent);
            }
        });

    }
}
