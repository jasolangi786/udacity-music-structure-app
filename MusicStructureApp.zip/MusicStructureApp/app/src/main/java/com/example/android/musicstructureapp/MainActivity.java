package com.example.android.musicstructureapp;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Music App");
        setContentView(R.layout.activity_main);

        TextView Artists = (TextView) findViewById(R.id.Artists);
        TextView Tracks = (TextView) findViewById(R.id.Tracks);
        TextView Albums = (TextView) findViewById(R.id.Albums);
        TextView list0 = (TextView) findViewById(R.id.playlist0);
        TextView list1 = (TextView) findViewById(R.id.playlist1);
        TextView list2 = (TextView) findViewById(R.id.playlist2);

        Artists.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artistIntent = new Intent(MainActivity.this, ArtistsActivity.class);
                startActivity(artistIntent);
            }
        });

    Tracks.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent tracksIntent = new Intent (MainActivity.this, TracksActivity.class);
            startActivity(tracksIntent);
        }
    });

        Albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent albumsIntent = new Intent (MainActivity.this, AlbumActivity.class);
                startActivity(albumsIntent);
            }
        });

        list0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent playList0Intent = new Intent (MainActivity.this, PlayListDetailActivity.class);
                startActivity(playList0Intent);
            }
        });

    list1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent playList1Intent = new Intent (MainActivity.this, PlayListDetailActivity.class);
            startActivity(playList1Intent);
        }

    });

        list2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent playList2Intent = new Intent (MainActivity.this, PlayListDetailActivity.class);
                startActivity(playList2Intent);

            }
        });

    }

    }