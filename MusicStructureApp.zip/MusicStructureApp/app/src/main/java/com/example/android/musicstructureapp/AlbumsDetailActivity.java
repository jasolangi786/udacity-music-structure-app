package com.example.android.musicstructureapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AlbumsDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Albums Details");
        setContentView(R.layout.activity_albums_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}