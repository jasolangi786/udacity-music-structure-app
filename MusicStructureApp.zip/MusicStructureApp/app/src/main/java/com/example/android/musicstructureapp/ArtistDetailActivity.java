package com.example.android.musicstructureapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ArtistDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Artists Details");
        setContentView(R.layout.activity_artist_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
